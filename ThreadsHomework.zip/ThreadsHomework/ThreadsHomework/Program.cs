﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadsHomework
{
    internal class Program
    {
        const int numberOfTasks = 5;
        static async Task Main(string[] args)
        {
            Random random = new Random();
            int[] numbers = Enumerable.Range(0, 5000000).Select(_ => random.Next(0, 1001)).ToArray();

            Stopwatch syncStopwatch = Stopwatch.StartNew();
            long syncSum = CalculateSumSynchronously(numbers);
            syncStopwatch.Stop();
            Console.WriteLine($"Sync calculation finished in {syncStopwatch.ElapsedMilliseconds} ms. Total sum: {syncSum}");

            Stopwatch asyncStopwatch = Stopwatch.StartNew();
            long asyncSum = await CalculateSumAsync(numbers);
            asyncStopwatch.Stop();
            Console.WriteLine($"Async calculation finished in {asyncStopwatch.ElapsedMilliseconds} ms. Total sum: {asyncSum}");
        }

        static long CalculateSumSynchronously(int[] numbers)
        {
            long sum = 0;
            foreach (var number in numbers)
            {
                sum += number;
            }
            return sum;
        }

        static async Task<long> CalculateSumAsync(int[] numbers)
        {
            var tasks = new Task<long>[numberOfTasks];
            var batchSize = numbers.Length / numberOfTasks;
            var completedTasksCount = 0;

            for (var i = 0; i < numberOfTasks; i++)
            {
                var start = i * batchSize;
                var end = i == numberOfTasks - 1 ? numbers.Length : (i + 1) * batchSize;
                tasks[i] = Task.Run(() => CalculateBatchSumAsync(numbers, start, end));
            }

            while (completedTasksCount < numberOfTasks)
            {
                await Task.WhenAny(tasks);
                completedTasksCount++;
            }

            long totalSum = 0;
            foreach (var task in tasks) totalSum += await task;
            return totalSum;
        }

        static async Task<long> CalculateBatchSumAsync(int[] numbers, int startIndex, int endIndex)
        {
            long sum = 0;
            for (int i = startIndex; i < endIndex; i++)
            {
                sum += numbers[i];
            }
            await Task.Delay(1);
            return sum;
        }
    

    }
}
